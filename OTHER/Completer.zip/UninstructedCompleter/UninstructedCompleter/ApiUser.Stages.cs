﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UninstructedCompleter
{
    partial class ApiUser
    {
        private void GetStartItems()
        {
            var craftBench = FindNearestItem(6);
            if (craftBench.HasValue && GetInventoryCount(5) == 0)
            {
                var sticks = FindNearestItem(2);
                var stone = FindNearestItem(1);

                MoveTo(craftBench.Value.Position.Value);
                MoveTo(sticks.Value.Position.Value);
                MoveTo(stone.Value.Position.Value);

                World.SetNeedUpdate();

                while (GetInventoryCount(2) < 2)
                {
                    sticks = FindNearestItem(2);
                    MoveTo(sticks.Value.Position.Value);

                    World.SetNeedUpdate();
                }

                while (GetInventoryCount(1) < 3)
                {
                    stone = FindNearestItem(1);
                    MoveTo(stone.Value.Position.Value);

                    World.SetNeedUpdate();
                }
            }
        }

        private void MakePickaxe()
        {
            if (TakeItem(6) && GetInventoryCount(5) == 0)
            {
                MoveTo(new(World.Width / 2, World.Height / 2));
                Player.Rotation = 0;
                Player.Use();
                Player.Interact("craft pickaxe");
            }
        }

        private void FindOre()
        {
            var map = World.Map;
            while (GetInventoryCount(3) < 20)
            {
                var oreBlock = FindNearestBlock(4, map);
                if (!oreBlock.HasValue)
                {
                    var remain = FindNearestItem(3);
                    if (remain.HasValue)
                    {
                        MoveTo(remain.Value.Position.Value);
                        World.SetNeedUpdate();
                    }
                    break;
                }
                MoveTo(oreBlock.Value);
                map[(int)oreBlock.Value.X, (int)oreBlock.Value.Y] = 0;
            }
        }

        private void FindSticks()
        {
            var map = World.Map;
            while (GetInventoryCount(2) < 40)
            {
                var bush = FindNearestBlock(3, map);
                if (!bush.HasValue)
                {
                    while (GetInventoryCount(2) < 40)
                    {
                        var stick = FindNearestItem(2);
                        if (stick.HasValue)
                        {
                            MoveTo(stick.Value.Position.Value);
                            World.SetNeedUpdate();
                        }
                        else break;
                    }
                    break;
                }
                MoveTo(bush.Value);
                map[(int)bush.Value.X, (int)bush.Value.Y] = 0;
            }
        }

        private void CraftIngots()
        {
            if (GetInventoryCount(4) < 20)
            {
                MoveTo(new(World.Width / 2 - 1, World.Height / 2 + 1));
                Player.Rotation = (int)Direction.right;
                for (int i = 0; i < 20; i++)
                {
                    Player.Interact("craft IronIngot");
                }
            }
        }

        private void ActivateLauncher()
        {
            var launcher = FindNearestBlock(6);
            MoveTo(launcher.Value - new System.Numerics.Vector2(1, 0));
            Player.Rotation = (int)Direction.right;
            Player.Interact("activate");
        }
    }
}
