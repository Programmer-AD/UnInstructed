﻿using System;
using System.IO;
using UninstructedAPI;

namespace UninstructedCompleter
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            var executor = new ApiExecutor("C:/Users/AndreyPC/Downloads/UninstructedLog.txt");
            try
            { 
                var user = new ApiUser();
                executor.Execute(user);
            }catch (Exception ex)
            {
                File.AppendAllText("C:/Users/AndreyPC/Downloads/UninstructedLog.txt", $"[Crush]:\r\n{ex}");
            }
            finally
            {
                executor.Dispose();
            }
        }
    }
}
