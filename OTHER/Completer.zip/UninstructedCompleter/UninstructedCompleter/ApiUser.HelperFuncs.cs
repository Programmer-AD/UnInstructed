﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Models;

namespace UninstructedCompleter
{
    partial class ApiUser
    {
        private Vector2? FindNearestBlock(int id, int[,] map = null)
        {
            if (map == null)
            {
                map = World.Map;
            }

            bool IsTarget(int x, int y)
            {
                return x >= 0 && y >= 0 && x < World.Width && y < World.Height && map[x, y] == id;
            }

            var maxRange = Math.Max(World.Width, World.Height);
            for (var range = 1; range < maxRange; range++)
            {
                var actions = 4 * range;
                int dx = 0, dy = -range;
                for (var i = 0; i < actions; i++)
                {
                    int x = (int)Player.Position.X + dx,
                        y = (int)Player.Position.Y + dy;

                    if (IsTarget(x, y))
                    {
                        return new(x, y);
                    }
                    switch (i / range)
                    {
                        case 0:
                            dx++;
                            dy++;
                            break;
                        case 1:
                            dx--;
                            dy++;
                            break;
                        case 2:
                            dx--;
                            dy--;
                            break;
                        case 3:
                            dx++;
                            dy--;
                            break;
                    }
                }
            }
            return null;
        }

        private Item? FindNearestItem(int id)
        {
            var playerPos = Player.Position;
            var items = World.Items;
            var sortedItems = items.Where(x => x.Id == id)
                .OrderBy(x => (playerPos - x.Position.Value).LengthSquared());

            var result = sortedItems.FirstOrDefault();
            if (result.Id == 0)
            {
                return null;
            }
            return result;
        }

        private void MoveTo(Vector2 position)
        {
            int posX = (int)Math.Round(position.X),
                posY = (int)Math.Round(position.Y);

            while (Math.Abs(posX - Player.Position.X) > 0.1f)
            {
                var move = Math.Min(1, Math.Abs(posX - Player.Position.X));
                if (posX - Player.Position.X > 0)
                {
                    BreakBlock(Direction.right);
                }
                else
                {
                    BreakBlock(Direction.left);
                }
                Player.Move(move);
            }

            
            while (Math.Abs(posY - Player.Position.Y) > 0.1f)
            {
                var move = Math.Min(1, Math.Abs(posY - Player.Position.Y));
                if (posY - Player.Position.Y > 0)
                {
                    BreakBlock(Direction.up);
                }
                else
                {
                    BreakBlock(Direction.down);
                }
                Player.Move(move);
            }
        }

        private bool BreakBlock(Direction direction)
        {
            Player.Rotation = (int)direction;
            if (!TakeItem(5)) return false;           
            var blockPosition = Player.Position + direction switch
            {
                Direction.up => new(0, 1),
                Direction.left => new(-1, 0),
                Direction.down => new(0, -1),
                Direction.right => new(1, 0),
                _ => throw new NotImplementedException(),
            };

            int blockX = (int)Math.Round(blockPosition.X),
                blockY = (int)Math.Round(blockPosition.Y);

            var blockInfo = World.GetBlockInfo(blockX, blockY);

            if (!blockInfo.CanBreak)
            {
                return false;
            }

            if (blockInfo.Id != 0)
            {
                while (blockInfo.Durability > 0)
                {
                    Player.UseOnBlock();
                    blockInfo = World.GetBlockInfo(blockX, blockY);
                }
            }
            return true;
        }

        private bool TakeItem(int id)
        {
            if (Player.HandItem.Id != id)
            {
                for (int i = 0; i < Player.Inventory.Count; i++)
                {
                    if (Player.Inventory[i].Id == id)
                    {
                        Player.Selected = i;
                        return true;
                    }
                }
                return false;
            }
            return true;
        }

        private int GetInventoryCount(int id)
        {
            return Player.Inventory.Where(x => x.Id == id).Sum(x => x.Count);
        }

        enum Direction
        {
            up = 0,
            left = 90,
            down = 180,
            right = 270
        }
    }
}
