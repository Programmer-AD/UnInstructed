﻿using System.Numerics;
using UninstructedAPI.Interfaces;
using UninstructedAPI.Models;

namespace UninstructedCompleter
{
    partial class ApiUser : IApiUser
    {
        public IPlayer Player { get; set; }
        public IWorld World { get; set; }

        public void OnInitted() { }

        public void OnStopping() { }

        public void Work()
        {
            GetStartItems();
            MakePickaxe();
            FindOre();
            FindSticks();
            CraftIngots();
            ActivateLauncher();
        }
    }
}
