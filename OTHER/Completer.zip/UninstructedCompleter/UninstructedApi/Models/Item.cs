﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace UninstructedAPI.Models
{
    public struct Item
    {
        public int Id, Count;
        public Vector2? Position;

        public Item(string data)
        {
            var parts = data.Split(' ');
            Id = int.Parse(parts[0]);

            Count = 0;
            Position = null;

            if (Id != 0)
            {
                Count = int.Parse(parts[1]);
                if (parts.Length > 2)
                {
                    var x = float.Parse(parts[2]);
                    var y = float.Parse(parts[3]);
                    Position = new Vector2(x, y);
                }
            }
        }
    }
}
