﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UninstructedAPI.Models
{
    public struct Block
    {
        public int Id;
        public bool CanGoThrough, CanBreak;
        public float Durability;

        public Block(string data)
        {
            var parts = data.Split(' ');
            Id = int.Parse(parts[0]);

            CanGoThrough = true;
            CanBreak = false;
            Durability = 0;

            if (Id != 0)
            {
                CanGoThrough = parts[1] != "0";
                CanBreak = parts[2] != "0";
                Durability = float.Parse(parts[3]);
            }
        }
    }
}
