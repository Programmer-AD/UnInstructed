﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace UninstructedAPI.Models
{
    public struct Entity
    {
        public int Id;
        public Vector2 Position;
        public float? Rotation, Health;
        
        public Entity(string data)
        {
            var parts = data.Split(' ');
            Id = int.Parse(parts[0]);

            Position = Vector2.Zero;
            Rotation = null;
            Health = null;

            if (Id != 0)
            {
                var x = float.Parse(parts[1]);
                var y = float.Parse(parts[2]);
                Position = new Vector2(x, y);

                if (parts.Length > 3)
                {
                    Rotation = float.Parse(parts[3]);
                    Health = float.Parse(parts[4]);
                }
            }
        }
    }
}
