﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using UninstructedAPI.Commands.Facades;
using UninstructedAPI.Commands.Groups;
using UninstructedAPI.Commands.IO;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI
{
    public sealed class ApiExecutor:IDisposable
    {
        private readonly ServiceProvider serviceProvider;
        private readonly WorkGroup workGroup;

        public ApiExecutor(string logFilePath = null)
        {
            var services = new ServiceCollection();

            services.AddInteractor(logFilePath)
                .AddCommandGroups()
                .AddFacades();

            serviceProvider = services.BuildServiceProvider();

            
            workGroup = serviceProvider.GetRequiredService<WorkGroup>();
        }

        public void Execute(IApiUser user)
        {
            workGroup.Init();

            var world = serviceProvider.GetRequiredService<IWorld>();
            world.ForceUpdate();
            user.World = world;

            var player = serviceProvider.GetRequiredService<IPlayer>();
            player.ForceUpdate();
            user.Player = player;

            user.OnInitted();

            workGroup.Start();
            user.Work();

            user.OnStopping();
            workGroup.Stop();
        }


        public void Dispose()
        {
            workGroup.Stop();
            serviceProvider.Dispose();
        }
    }
}
