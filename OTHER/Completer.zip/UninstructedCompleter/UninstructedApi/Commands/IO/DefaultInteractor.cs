﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands.IO
{
    internal class DefaultInteractor : IInteractor
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }

        public void WriteLine(string text)
        {
            Console.WriteLine(text);
        }
    }
}
