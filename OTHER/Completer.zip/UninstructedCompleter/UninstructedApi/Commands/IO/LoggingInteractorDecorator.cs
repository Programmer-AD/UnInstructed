﻿using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands.IO
{
    internal sealed class LoggingInteractorDecorator : IInteractor, IDisposable
    {
        private readonly IInteractor interactor;
        private readonly FileStream fileStream;
        private readonly StreamWriter logWriter;

        public LoggingInteractorDecorator(IInteractor interactor, string logFilePath)
        {
            fileStream = new FileStream(logFilePath, FileMode.Create);
            logWriter = new StreamWriter(fileStream);
            this.interactor = interactor;
        }

        public void WriteLine(string text)
        {
            logWriter.WriteLine($"[Send, {DateTime.Now}] {text}");
            logWriter.Flush();
            interactor.WriteLine(text);
        }

        public string ReadLine()
        {
            var text = interactor.ReadLine();
            logWriter.WriteLine($"[Recieve, {DateTime.Now}] {text}");
            logWriter.Flush();
            return text;
        }

        public void Dispose()
        {
            logWriter.Close();
            logWriter.Dispose();
            fileStream.Dispose();
        }
    }
}
