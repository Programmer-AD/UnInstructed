﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands.IO
{
    internal static class InteractorServiceCollectionExtensions
    {
        public static IServiceCollection AddInteractor(this IServiceCollection services, string logFilePath = null)
        {
            return services.AddSingleton(_ =>
            {
                IInteractor interactor = new DefaultInteractor();
                if (!string.IsNullOrEmpty(logFilePath))
                {
                    var logged = new LoggingInteractorDecorator(interactor, logFilePath);
                    interactor = logged;
                }
                return interactor;
            });
        }
    }
}
