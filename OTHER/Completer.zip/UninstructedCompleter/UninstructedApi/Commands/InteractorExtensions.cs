﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Commands.Exceptions;
using UninstructedAPI.Commands.IO;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands
{
    internal static class InteractorExtensions
    {
        public static T OneLineResult<T>(this IInteractor interactor, string command, Func<string, T> lineParser)
        {
            interactor.SendCommand(command);
            var line = interactor.ReadLine();
            var result = lineParser(line);
            return result;
        }

        public static IReadOnlyList<T> ListResult<T>(this IInteractor interactor, string command, Func<string, T> lineParser)
        {
            interactor.SendCommand(command);

            var sizeString = interactor.ReadLine();
            var size = int.Parse(sizeString);

            var result = new T[size];

            for (int i = 0; i < size; i++)
            {
                var line = interactor.ReadLine();
                var parsed = lineParser(line);
                result[i] = parsed;
            }
            interactor.ReadLine();

            return result;
        }

        public static void SendCommand(this IInteractor interactor, string command)
        {
            interactor.WriteLine(command);
            var status = interactor.ReadLine();
            switch (status)
            {
                case "ok":
                    return;
                case "error":
                    {
                        var description = interactor.ReadLine();
                        throw new CommandFormatException(description);
                    }
                case "died":
                    throw new PlayerDiedException();
                default:
                    return;
            }
        }
    }
}
