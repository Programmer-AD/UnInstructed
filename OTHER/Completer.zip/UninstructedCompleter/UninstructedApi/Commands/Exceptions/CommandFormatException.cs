﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UninstructedAPI.Commands.Exceptions
{
    [Serializable]
    internal class CommandFormatException : Exception
    {
        public CommandFormatException(string message) : base(message) { }
    }
}
