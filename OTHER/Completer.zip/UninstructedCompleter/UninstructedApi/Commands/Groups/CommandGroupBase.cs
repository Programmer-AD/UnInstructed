﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands.Groups
{
    internal abstract class CommandGroupBase
    {
        private readonly string groupBase;
        private readonly IInteractor interactor;

        protected CommandGroupBase(string groupBase, IInteractor interactor)
        {
            this.groupBase = groupBase;
            this.interactor = interactor;
        }

        private string Prepare(string commandPart)
            => $"{groupBase} {commandPart}";

        protected T OneLineResult<T>(string commandPart, Func<string, T> lineParser)
            => interactor.OneLineResult(Prepare(commandPart), lineParser);

        protected IReadOnlyList<T> ListResult<T>(string commandPart, Func<string, T> lineParser)
            => interactor.ListResult(Prepare(commandPart), lineParser);

        protected void SendCommand(string commandPart)
            => interactor.SendCommand(Prepare(commandPart));

        protected string ReadLine()
            => interactor.ReadLine();
    }
}
