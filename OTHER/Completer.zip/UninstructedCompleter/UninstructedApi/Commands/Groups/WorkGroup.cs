﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands.Groups
{
    internal class WorkGroup : CommandGroupBase
    {
        public WorkGroup(IInteractor interactor) : base("work", interactor) { }

        public void Init()
            => SendCommand("init");

        public void Start()
            => SendCommand("start");

        public void Stop()
            => SendCommand("stop");
    }
}
