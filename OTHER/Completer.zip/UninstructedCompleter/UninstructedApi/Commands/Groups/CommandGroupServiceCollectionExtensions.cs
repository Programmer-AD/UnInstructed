﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace UninstructedAPI.Commands.Groups
{
    internal static class CommandGroupServiceCollectionExtensions
    {
        public static IServiceCollection AddCommandGroups(this IServiceCollection services)
        {
            return services.AddSingleton<WorkGroup>()
                .AddSingleton<GetGroupPrimary>()
                .AddSingleton<GetGroupPlayer>()
                .AddSingleton<PlayerGroup>();
        }
    }
}
