﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands.Groups
{
    internal class PlayerGroup : CommandGroupBase
    {
        public PlayerGroup(IInteractor interactor) : base("player", interactor) { }

        public void Move(float distance)
            => SendCommand($"move {distance}");

        public void RotateBy(float angle)
            => SendCommand($"rotate {angle}");

        public void RotateTo(float angle)
            => SendCommand($"rotate to {angle}");

        public void Select(int slotNumber)
            => SendCommand($"select {slotNumber}");

        public void Drop(int? count = null)
        {
            if (count.HasValue)
            {
                SendCommand($"drop {count.Value}");
            }
            else
            {
                SendCommand("drop");
            }
        }

        public void Use()
            => SendCommand("use");

        public void UseOnBlock()
            => SendCommand("use onblock");

        public void Interact(string command = null, Action<Func<string>> resultReader = null)
        {
            if (!string.IsNullOrEmpty(command))
            {
                SendCommand($"interact {command}");
            }
            else
            {
                SendCommand("interact");
            }
            resultReader?.Invoke(ReadLine);
        }
    }
}
