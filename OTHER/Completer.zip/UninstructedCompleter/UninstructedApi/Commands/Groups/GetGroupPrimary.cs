﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Interfaces;
using UninstructedAPI.Models;

namespace UninstructedAPI.Commands.Groups
{
    internal class GetGroupPrimary : CommandGroupBase
    {
        public GetGroupPrimary(IInteractor interactor) : base("get", interactor) { }

        public (int width, int height) GetMapSize()
            => OneLineResult("map size", ParseSizes);

        /// <remarks>
        /// if <paramref name="map"/> is null, than it will be inited automaticly
        /// </remarks>
        public void GetMap(ref int[,] map)
        {
            SendCommand("map");
            var line = ReadLine();
            var sizes = ParseSizes(line);

            if (map == null)
            {
                map = new int[sizes.width, sizes.height];
            }

            for (int y = 0; y < sizes.height; y++)
            {
                line = ReadLine();

                var values = line.Split(' ');
                for (int x = 0; x < sizes.width; x++)
                {
                    map[x, y] = int.Parse(values[x]);
                }
            }
            ReadLine();
        }

        public int[,] GetMapPart(int sx, int sy, int ex, int ey)
        {
            SendCommand($"map {sx} {sy} {ex} {ey}");
            var line = ReadLine();
            var sizes = ParseSizes(line);

            var mapPart = new int[sizes.width, sizes.height];

            for (int y = 0; y < sizes.height; y++)
            {
                line = ReadLine();

                var values = line.Split(' ');
                for (int x = 0; x < sizes.width; x++)
                {
                    mapPart[x, y] = int.Parse(values[x]);
                }
            }
            ReadLine();

            return mapPart;
        }

        public IReadOnlyList<Entity> GetEntityList()
            => ListResult("list entity", line => new Entity(line));

        public IReadOnlyList<Item> GetItemList()
            => ListResult("list item", line => new Item(line));

        public Block GetBlockInfo(int x, int y)
            => OneLineResult($"info block {x} {y}", line => new Block(line));

        public Entity GetEntityInfo(int listNum)
            => OneLineResult($"info entity {listNum}", line => new Entity(line));

        public Entity GetPlayerInfo()
            => OneLineResult($"info player", line => new Entity(line));

        private (int width, int height) ParseSizes(string line)
        {
            var sizes = line.Split(' ').Select(part => int.Parse(part)).ToArray();
            return (sizes[0], sizes[1]);
        }
    }
}
