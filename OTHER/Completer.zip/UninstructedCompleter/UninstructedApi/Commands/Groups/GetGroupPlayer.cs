﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Interfaces;
using UninstructedAPI.Models;

namespace UninstructedAPI.Commands.Groups
{
    internal class GetGroupPlayer:CommandGroupBase
    {
        public GetGroupPlayer(IInteractor interactor):base("get player", interactor) {}

        public Vector2 GetPosition() {
            var result = OneLineResult("position", line => {
                var parts = line.Split(' ').Select(part => float.Parse(part)).ToArray();
                return new Vector2(parts[0], parts[1]);
            });
            return result;
        }
        public float GetRotation()
             => OneLineResult("rotation", float.Parse);
        
        public float GetHealth()
            => OneLineResult("health", float.Parse);

        public IReadOnlyList<Item> GetInventory()
            => ListResult("inventory", line => new Item(line));

        public int GetSelected()
            => OneLineResult("selected", int.Parse);
        
        public Item GetHandItem()
            => OneLineResult("handItem", line => new Item(line));
    }
}
