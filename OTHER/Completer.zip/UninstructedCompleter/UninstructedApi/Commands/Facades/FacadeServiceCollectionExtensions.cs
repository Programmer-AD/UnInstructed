﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands.Facades
{
    internal static class FacadeServiceCollectionExtensions
    {
        public static IServiceCollection AddFacades(this IServiceCollection services)
        {
            return services.AddSingleton<IPlayer, PlayerFacade>()
                .AddSingleton<IWorld, WorldFacade>();
        }
    }
}
