﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Interfaces;

namespace UninstructedAPI.Commands.Facades
{
    internal class LazyUpdateable<T>:IUpdateable
    {
        public static implicit operator T(LazyUpdateable<T> updateable)
            => updateable.Value;

        private readonly Func<T, T> updater;
        private bool needUpdate;
        private T value;

        public LazyUpdateable(Func<T, T> updater)
        {
            this.updater = updater;
            needUpdate = true;
        }

        public bool NeedUpdate => needUpdate;
        public T Value {
            get
            {
                if (needUpdate)
                {
                    Update();
                }
                return value;
            }
        }

        public void SetNeedUpdate()
        {
            needUpdate = true;
        }
        public void ForceUpdate()
        {
            Update();
        }

        private void Update()
        {
            value = updater(value);
            needUpdate = false;
        }
    }
}
