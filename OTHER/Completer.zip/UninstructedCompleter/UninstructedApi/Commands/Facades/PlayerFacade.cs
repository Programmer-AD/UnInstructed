﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Commands.Groups;
using UninstructedAPI.Interfaces;
using UninstructedAPI.Models;

namespace UninstructedAPI.Commands.Facades
{
    internal class PlayerFacade : IPlayer
    {
        private readonly PlayerGroup player;
        private readonly GetGroupPlayer getPlayer;

        public PlayerFacade(PlayerGroup player, GetGroupPlayer getPlayer)
        {
            this.player = player;
            this.getPlayer = getPlayer;

            position = new(_ => getPlayer.GetPosition());
            rotation = new(_ => getPlayer.GetRotation());
            inventory = new(_ => getPlayer.GetInventory());
            handItem = new(_ => getPlayer.GetHandItem());
        }

        private readonly LazyUpdateable<Vector2> position;
        public Vector2 Position => position.Value;

        private readonly LazyUpdateable<float> rotation;
        public float Rotation
        {
            get => rotation.Value;
            set
            {
                player.RotateTo(value);
                SetNeedUpdate();
            }
        }

        private int selected;
        public int Selected
        {
            get => selected;
            set
            {
                if (value != selected)
                {
                    player.Select(value);
                    selected = value;
                    SetNeedUpdate();
                }
            }
        }

        private readonly LazyUpdateable<IReadOnlyList<Item>> inventory;
        public IReadOnlyList<Item> Inventory => inventory.Value;

        private readonly LazyUpdateable<Item> handItem;
        public Item HandItem => handItem.Value;

        public void Move(float distance)
        {
            if (distance != 0)
            {
                player.Move(distance);
                SetNeedUpdate();
            }
        }

        public void RotateBy(float angle)
        {
            if (angle != 0)
            {
                player.RotateBy(angle);
                SetNeedUpdate();
            }
        }

        public void Drop(int? count = null)
        {
            player.Drop(count);
            SetNeedUpdate();
        }

        public void Use()
        {
            player.Use();
            SetNeedUpdate();
        }

        public void UseOnBlock()
        {
            player.UseOnBlock();
            SetNeedUpdate();
        }

        public void Interact(string command = null, Action<Func<string>> resultReader = null)
        {
            player.Interact(command, resultReader);
            SetNeedUpdate();
        }

        public void SetNeedUpdate()
        {
            position.SetNeedUpdate();
            rotation.SetNeedUpdate();
            inventory.SetNeedUpdate();
            handItem.SetNeedUpdate();
        }

        public void ForceUpdate()
        {
            position.ForceUpdate();
            rotation.ForceUpdate();
            inventory.ForceUpdate();
            handItem.ForceUpdate();
            selected = getPlayer.GetSelected();
        }
    }
}
