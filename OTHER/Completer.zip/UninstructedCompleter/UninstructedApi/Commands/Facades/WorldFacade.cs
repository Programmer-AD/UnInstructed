﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Commands.Groups;
using UninstructedAPI.Interfaces;
using UninstructedAPI.Models;

namespace UninstructedAPI.Commands.Facades
{
    internal class WorldFacade : IWorld
    {
        private readonly GetGroupPrimary getGroup;

        public WorldFacade(GetGroupPrimary getGroup)
        {
            this.getGroup = getGroup;

            map = new(old =>
            {
                getGroup.GetMap(ref old);
                return old;
            });

            entities = new(_ => getGroup.GetEntityList());
            items = new(_ => getGroup.GetItemList());
        }

        public int Width { get; private set; }
        public int Height { get; private set; }

        private readonly LazyUpdateable<int[,]> map;
        public int[,] Map => map;

        private readonly LazyUpdateable<IReadOnlyList<Entity>> entities;
        public IReadOnlyList<Entity> Entities => entities.Value;

        private readonly LazyUpdateable<IReadOnlyList<Item>> items;
        public IReadOnlyList<Item> Items => items.Value;

        public Block GetBlockInfo(int x, int y)
            => getGroup.GetBlockInfo(x, y);

        public Entity GetEntityInfo(int listNum)
            => getGroup.GetEntityInfo(listNum);

        public void SetNeedUpdate()
        {
            map.SetNeedUpdate();
            entities.SetNeedUpdate();
            items.SetNeedUpdate();
        }

        public void ForceUpdate()
        {
            map.ForceUpdate();
            entities.ForceUpdate();
            items.ForceUpdate();

            Width = map.Value.GetLength(0);
            Height = map.Value.GetLength(1);
        }
    }
}
