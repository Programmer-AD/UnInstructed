﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Models;

namespace UninstructedAPI.Interfaces
{
    public interface IWorld : IUpdateable
    {
        int Width { get; }
        int Height { get; }
        int[,] Map { get; }

        IReadOnlyList<Entity> Entities { get; }
        IReadOnlyList<Item> Items { get; }

        Block GetBlockInfo(int x, int y);
        Entity GetEntityInfo(int listNum);
    }
}
