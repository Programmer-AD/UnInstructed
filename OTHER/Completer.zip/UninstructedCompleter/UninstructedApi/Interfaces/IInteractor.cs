﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UninstructedAPI.Interfaces
{
    internal interface IInteractor
    {
        void WriteLine(string text);
        string ReadLine();
    }
}
