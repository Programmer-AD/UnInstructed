﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UninstructedAPI.Interfaces
{
    public interface IApiUser
    {
        IPlayer Player { get; set; }
        IWorld World { get; set; }

        void OnInitted();
        void Work();
        void OnStopping();
    }
}
