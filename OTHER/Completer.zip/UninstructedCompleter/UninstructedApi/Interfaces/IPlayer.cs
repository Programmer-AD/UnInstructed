﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using UninstructedAPI.Models;

namespace UninstructedAPI.Interfaces
{
    public interface IPlayer : IUpdateable
    {
        Vector2 Position { get; }
        float Rotation { get; set; }
        int Selected { get; set; }

        Item HandItem { get; }
        IReadOnlyList<Item> Inventory { get; }

        void Move(float distance);
        void RotateBy(float angle);
        void Drop(int? count = null);
        void Use();
        void UseOnBlock();
        void Interact(string command = null, Action<Func<string>> resultReader = null);
    }
}
